$(function() {

$('#chkveg').multiselect({

includeSelectAllOption: true

});
$('#chkveg1').multiselect({

includeSelectAllOption: true

});
});