$(function() {



$('#foodtype').multiselect({

includeSelectAllOption: true

});
$('#filter2').multiselect({

includeSelectAllOption: true

});

$('#filter3').multiselect({

includeSelectAllOption: true

});
$('#filter4').multiselect({

includeSelectAllOption: true

});
 $('#datetimepicker1').datetimepicker();
});
