module.exports = function() {
    var client = './src/';
    //var clientApp = client + 'app/';
    var temp = './.tmp/';

    //var server = './src/server/';
    var config = {
        source: './src/',
        alljs: ['./src/**/*.js',
            './*.js'
        ],
        build: './build',
        client: client,
        index: client + 'index.html',

        js: [
            client + '**/*.module.js',
            client + '**/*.js',
            '!' + client + '**/*.spec.js'
        ],

        css: temp + 'styles.css',
        fonts: './src/assets/fonts/*.*',
        images: ['./src/assets/images/**/*.*', './src/.jpg'],
        htmltemplates: [
            client + '**/*.html',
            '!' + client + 'index.html'
        ],
        less: client + 'assets/styles/*.less',
        styles: client + 'assets/styles/*.css',
        temp: temp,
        //server: server,

        templateCache: {
            file: 'templates.js',
            options: {
                module: 'vrApp',
                standAlone: false,
                root: ''
            }
        },

        bower: {
            json: require('./bower.json'),
            directory: './bower_components',
            ignorePath: '..'
        },

        defaultPort: 8080,
        nodeServer: 'server.js'
    };

    config.getWireDepDefaultOptions = function() {
        var options = {
            bowerJson: config.bower.json,
            directory: config.bower.directory,
            ignorePath: config.bower.ignorePath
        };
        return options;
    };

    return config;
};