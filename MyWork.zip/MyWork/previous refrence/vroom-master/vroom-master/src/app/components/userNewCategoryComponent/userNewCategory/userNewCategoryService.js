userCatCmp.factory('userCategoryService', function($http, $cookies) {
    var selectedCategory = "";

    var getCategory = function() {
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/categoryData');
    };

    // function setSelectedCategory(val) {
    //     selectedCategory = val;
    //     console.log(selectedCategory);
    // }

    function getSelectedCategory() {
        // return selectedCategory;
        return ($cookies.get("Category"));
    }

    return {
        // setSelectedCategory: setSelectedCategory,
        getSelectedCategory: getSelectedCategory,
        getCategory: getCategory
    };

});