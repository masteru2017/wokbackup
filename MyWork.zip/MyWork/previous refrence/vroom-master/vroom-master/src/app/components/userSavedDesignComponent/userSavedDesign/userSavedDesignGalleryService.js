savedDesigns.factory("userSavedDesignGalleryService", function($http, $cookies) {

    var editDesignRoom;

    function setEditDesignRoom(room) {
        console.log(room);
        editDesignRoom = room;
        $cookies.putObject("savedRoom", room);
    }

    function getEditDesignRoom() {
        // return editDesignRoom;

        return ($cookies.getObject("savedRoom"));
    }


    return {
        editDesignRoom: editDesignRoom,
        setEditDesignRoom: setEditDesignRoom,
        getEditDesignRoom: getEditDesignRoom,
        // getDesigns: function() {
        //     // return $http({ method: 'GET', url: "assets/data/userSavedDesigns.json" });
        //     return $http.get('/userSavedDesigns');
        // },
        getDesigns: function(userMid) {
            console.log(userMid);
            // return $http.post('http://digital-coe-api.azurewebsites.net/vroom/userSavedDesigns', userMid);
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/userSavedDesigns', userMid);
        },
        deleteDesign: function(room, mid) {
            // return $http.post('http://digital-coe-api.azurewebsites.net/vroom/deleteUserSavedDesigns', [mid, index]);
            console.log(mid);
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/deleteUserSavedDesigns', [room, mid]);
        },
        // replaceUserDesign.function()

        replaceEditedDesign: function(mid) {
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/replaceSavedDesigns', mid);
        }
    };

});