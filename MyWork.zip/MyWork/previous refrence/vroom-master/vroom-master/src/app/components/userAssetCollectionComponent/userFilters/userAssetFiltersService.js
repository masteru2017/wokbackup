astFilterCmp.factory("userAssetFiltersService", function($http) {
    // return {
    // assets: [{
    //     assetImg: 'assets/images/1.jpg'
    // }, {
    //     assetImg: 'assets/images/2.jpg'
    // }, {
    //     assetImg: 'assets/images/3.jpg'
    // }, {
    //     assetImg: 'assets/images/2.jpg'
    // }, {
    //     assetImg: 'assets/images/3.jpg'
    // }, {
    //     assetImg: 'assets/images/1.jpg'
    // }],
    var getCategories = function() {
        // return $http({ method: 'GET', url: "assets/data/userAssetCollectionCategories.json" });
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/userAssetCategories');
    };

    // var getRooms = function() {
    //     return $http({ method: 'GET', url: "assets/data/userAssetCollectionRooms.json" });
    // };
    var hotelRooms = function() {
        // return $http({ method: 'GET', url: "assets/data/hotelrooms.json" });
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/hotelRooms');
    };
    var homeRooms = function() {
        // return $http({ method: 'GET', url: "assets/data/homerooms.json" });
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/homeRooms');
    };
    var salonRooms = function() {
        // return $http({ method: 'GET', url: "assets/data/salonrooms.json" });
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/salonRooms');
    };

    // categories: [{
    //     categoryName: 'Home',
    //     id: 'homeSwitch',
    //     name: 'home',
    //     labelFor: 'homeSwitch'
    // }, {
    //     categoryName: 'Business',
    //     id: 'businessSwitch',
    //     name: 'business',
    //     labelFor: 'businessSwitch'
    // }, {
    //     categoryName: 'Saloon',
    //     id: 'saloonSwitch',
    //     name: 'saloon',
    //     labelFor: 'saloonSwitch'
    // }, {
    //     categoryName: 'Hotel',
    //     id: 'hotelSwitch',
    //     name: 'hotel',
    //     labelFor: 'hotelSwitch'
    // }, {
    //     categoryName: 'Corporate',
    //     id: 'corporateSwitch',
    //     name: 'corporate',
    //     labelFor: 'corporateSwitch'
    // }, {
    //     categoryName: 'Medical',
    //     id: 'medicalSwitch',
    //     name: 'medical',
    //     labelFor: 'medicalSwitch'
    // }],


    // rooms: [{
    //     roomName: 'Living',
    //     id: 'livingSwitch',
    //     name: 'living',
    //     labelFor: 'livingSwitch'
    // }, {
    //     roomName: 'Kitchen',
    //     id: 'kitchenSwitch',
    //     name: 'kitchen',
    //     labelFor: 'kitchenSwitch'
    // }, {
    //     roomName: 'Drawing',
    //     id: 'drawingSwitch',
    //     name: 'drawing',
    //     labelFor: 'drawingSwitch'
    // }, {
    //     roomName: 'Dining',
    //     id: 'diningSwitch',
    //     name: 'dining',
    //     labelFor: 'diningSwitch'
    // }, {
    //     roomName: 'Bedroom',
    //     id: 'bedroomSwitch',
    //     name: 'bedroom',
    //     labelFor: 'bedroomSwitch'
    // }]

    // }


    return {
        getCategories: getCategories,
        // getRooms: getRooms,
        homeRooms: homeRooms,
        hotelRooms: hotelRooms,
        salonRooms: salonRooms
    }
});