var homeCmp = angular.module('userApp', ['duScroll']);
homeCmp.value('duScrollOffset', 0);
homeCmp.value('duScrollDuration', 1200);

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

function OpenAboutUs() {

    document.getElementById("AboutUs").style.width = "100%";
}

function CloseAboutUs() {
    document.getElementById("AboutUs").style.width = "0";
}

homeCmp.component('homeComponent', {
    transclude: true,

    templateUrl: 'app/components/userHomeComponent/userHomeComponent/userHomePage.html',
    controller: function($scope, $http, $location, adalAuthenticationService, $document, $cookies) {



        this.$onInit = function() {
            var self = this;
            this.ourImg = "assets/images/common/mindtree.png";
            this.ourMsg = "We see possibilities where others see a full stop";
            this.AboutUs = [{
                name: "Akash",
                "img": "assets/images/ourImages/akash.png",
                "message": "Akash Singh, Put your heart, mind, and soul into even your smallest acts. This is the secret of success."
            }, {
                name: "Vivek",
                "img": "assets/images/ourImages/vivek.png",
                "message": "Vivek, All you need in this life is ignorance and confidence, and then success is sure."
            }, {
                name: "Monika",
                "img": "assets/images/ourImages/monika.png",
                "message": "Monika. Everything happens for a reason and that reson is always good. Be positive."
            }, {
                name: "Arijith",
                "img": "assets/images/ourImages/arijit.png",
                "message": "Arijit Nag, A leader is one who knows the way, goes the way, and shows the way. "
            }, {
                name: "Sravan",
                "img": "assets/images/ourImages/sravan.png",
                "message": "Sravan, Very little is needed to make a happy life; it is all within yourself, in your way of thinking."
            }, {
                name: "Belal",
                "img": "assets/images/ourImages/belal.png",
                "message": "Belal, It is possible to fly without motors, but not without knowledge and skill."
            }, ];
            this.aboutUsfunction = function(index) {
                this.ourImg = self.AboutUs[index].img;
                this.ourMsg = self.AboutUs[index].message;
            };
            this.userName = "";
            this.userMid = "";
            // self.token = adalAuthenticationService.acquireToken(adalAuthenticationService.config.loginResource).$$state.value;
            if (adalAuthenticationService.userInfo && adalAuthenticationService.userInfo.isAuthenticated) {
                console.log("Authenticated");
                // $http({
                //     url: 'https://orchard2016api.azurewebsites.net/books',
                //     method: "GET",
                //     headers: { "Authorization": "Bearer " + self.token }
                // }).then(function(response) {
                //     console.log(response);
                // }, function(err_status) {
                //     console.log(err_status);
                // });
                this.getPhoto = function(adalAuthenticationService) {
                    var adal = new AuthenticationContext(adalAuthenticationService.config);
                    adal.acquireToken("https://graph.microsoft.com", function(error, token) {
                        // console.log(token);
                        var request = new XMLHttpRequest();
                        request.open("GET", "https://graph.microsoft.com/beta/me/Photo/$value");
                        request.setRequestHeader("Authorization", "Bearer " + token);
                        request.responseType = "blob";
                        request.onload = function() {
                            if (request.readyState === 4 && request.status === 200) {
                                var reader = new FileReader();
                                reader.onload = function() {
                                    console.log("sending url");
                                    //console.log(reader.result);
                                    document.getElementById('userImage').src = reader.result;

                                };
                                reader.readAsDataURL(request.response);
                            }
                        };
                        request.send(null);
                    });
                };
                // self.userName = adalAuthenticationService.userInfo.profile.name;
                this.getPhoto(adalAuthenticationService);
            } else {
                console.log("not authenticated");
            }

            this.value = window.innerHeight;
            // console.log(this.value);
            this.userName = adalAuthenticationService.userInfo.profile.given_name;
            console.log(adalAuthenticationService);
            this.userMid = adalAuthenticationService.userInfo.userName.split('@')[0];
            $cookies.put("userMid", this.userMid);
            // console.log(this.userName);
            // console.log(adalAuthenticationService);
            // this.imageUrl = getPhoto(adalAuthenticationService);

            this.logout = function() {
                adalAuthenticationService.logOut();
            };
            this.scrolltoHref = function(id) {
                var x = angular.element(document.getElementById(id));
                $document.scrollToElementAnimated(x);
            };

        };



    }
});