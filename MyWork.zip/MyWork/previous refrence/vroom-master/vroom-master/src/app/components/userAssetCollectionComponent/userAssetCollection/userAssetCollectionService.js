astColl.factory("assetCollectionGalleryService", function($http, $cookies) {
    var name = "";
    return {
        // assets: function(callback) {
        //     $http.get('app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollection.json').success(callback);
        // },


        // categories: function(callback) {
        //     $http.get('app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollectionCategories.json').success(callback);
        // },
        getAssets: function() {
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/assetCollectionData');
        },

        getRoomDesigns: function() {
            // return $http({ method: 'GET', url: "assets/data/roomTypeCollection.json" });
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/roomTypeData');
        },


        getFavs: function(mid) {
            // return $http.get('http://digital-coe-api.azurewebsites.net/vroom/getAssetData');
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/getAssetData', mid);
        },
        // getCategories: function() {
        //     return $http({ method: 'GET', url: "app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollection.json" });
        // },

        // rooms: function() {
        //     return $http.get('app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollectionRooms.json').then(function(response) {
        //         console.log(response.data);
        //         return response.data;
        //     });
        // }




        getSelectedAssetImage: function() {
            // return selectedAsset;
            return ($cookies.getObject("Asset").assetUrl);
        },

        getSelectedAssetName: function() {
            // return selectedAssetName;
            return ($cookies.getObject("Asset").assetName);
        },

        getSelectedAsset: function() {
            return ($cookies.getObject("Asset"));
        },

        getSelectedAssetCategory: function() {
            // return selectedAssetCategory;
            return ($cookies.getObject("Asset").assetCategory);
        },

        getSelectedRoomType: function() {
            // return selectedRoomType;
            return ($cookies.getObject("Asset").assetRoomType);
        },

        getSelectedSubCat: function() {
            // return selectedSubCat;
            return ($cookies.getObject("Asset").assetSubCategory);
        },

        getSelectedTheme: function() {
            // return selectedTheme;
            return ($cookies.getObject("Asset").assetTheme);
        },








        setName: function(val) {
            name = val;
            console.log(name);
        },

        getName: function() {
            return name;
        }










    };

});