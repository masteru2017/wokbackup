var ast = angular.module("userApp");
ast.component('assetDetails', {

        templateUrl: 'app/components/userAssetPageComponent/userAsset.html',
        controller: function(assetCollectionGalleryService, assetGalleryService, $cookies) {
            var self = this;

            var userMid = $cookies.get("userMid").toString();
            this.menuarray = [];
            this.showassetphotos = function(x) {
                var count = 0;
                var roomselcount = 0;
                if (this.menuarray.length === 0)
                    return false;
                for (var i1 = 0; i1 < this.menuarray.length; i1++) {
                    roomselcount = 0;
                    for (var j1 = 0; j1 < this.menuarray[i1].length; j1++)
                        if (!this.menuarray[i1][j1].checked)
                            roomselcount++;
                    if (roomselcount === this.menuarray[i1].length) {
                        // console.log("entering category");
                        for (var k1 = 0; k1 < x.assetCategory.length; k1++) {
                            if (x.assetCategory[k1] == this.menuarray[i1].heading)
                                return false;
                        }
                    }
                }

                for (var i = 0; i < this.menuarray.length; i++)
                    for (var j = 0; j < this.menuarray[i].length; j++) {

                        // console.log(this.menuarray.length, this.menuarray[i].length);
                        // console.log(this.menuarray[i][j].name);
                        // console.log(this.menuarray[i][j].checked);

                        if (this.menuarray[i][j].checked == true) {
                            // console.log("entering the selected menu")
                            for (var k = 0; k < x.assetRoomType.length; k++) {
                                if (x.assetRoomType[k] == this.menuarray[i][j].name)
                                    count++;
                            }
                        }


                    }
                    // console.log(count);
                if (count > 0)
                    return false;
                else
                    return true;

            };

            // self.setAsset = assetCollectionGalleryService.getAsset();
            // console.log("I got my asset " + self.setAsset);

            self.selectedAsset = assetCollectionGalleryService.getSelectedAssetImage();
            self.selectedAssetName = assetCollectionGalleryService.getSelectedAssetName();
            self.selectedAssetCategory = assetCollectionGalleryService.getSelectedAssetCategory();
            self.selectedRoomType = assetCollectionGalleryService.getSelectedRoomType();
            self.selectedSubCat = assetCollectionGalleryService.getSelectedSubCat();
            self.selectedTheme = assetCollectionGalleryService.getSelectedTheme();
            console.log(self.selectedAsset);

            // console.log(assetCollectionGalleryService.getSelectedAsset());


            this.check = function() {
                // console.log(assetCollectionGalleryService.getSelectedAsset());

                var asset = assetCollectionGalleryService.getSelectedAsset();

                assetGalleryService.chkAsset(asset, { "MID": userMid }).then(function successCallback(response) {
                    console.log(response.data);

                    // self.favColl = response.data;
                    // console.log(self.favColl);

                    // console.log(response.data[0].assetUrl);
                    console.log(asset);

                    console.log(asset.assetUrl);



                    if (response.data.length == 0) {
                        self.add = true;
                        self.rem = false;


                    } else {
                        self.add = false;
                        self.rem = true;
                    }

                    // if (response.data.length === 0) {
                    //     self.add = true;
                    //     self.rem = false;
                    // }

                }, function errorCallback(response) {
                    console.log(response.statusText);
                });
                // console.log(assetGalleryService.chkAsset(asset));

            }
            this.check();

            this.startFrom = 0;
            this.next = function() {
                // console.log(self.assets.length);
                if (self.startFrom < self.assets.length) {
                    self.startFrom += 4;
                }
            };
            this.previous = function() {
                if (self.startFrom > 0) {
                    self.startFrom -= 4;
                }
            };


            this.favs = function() {
                // console.log(assetCollectionGalleryService.getSelectedAsset());
                self.add = false;
                self.rem = true;
                // var mid = $cookies.get("UserInfo").toString();
                // console.log(mid);
                var asset = assetCollectionGalleryService.getSelectedAsset();
                console.log(asset);

                assetGalleryService.sendAsset(asset, { "MID": userMid }).then(function(response) {
                    console.log(response.data);
                });
            }
            this.rmfavs = function() {
                // console.log(assetCollectionGalleryService.getSelectedAsset());
                self.add = true;
                self.rem = false;
                var asset = assetCollectionGalleryService.getSelectedAsset();
                // var coll = self.favColl;

                assetGalleryService.rmAsset(asset, { "MID": userMid }).then(function(response) {
                    console.log(response);
                });
            }

            assetCollectionGalleryService.getAssets().then(function successCallback(response) {
                self.assets = response.data;
            }, function errorCallback(response) {
                // self.assets = "Error: " + response.statusText;
            });

            this.assetInfo = function(asset) {
                $cookies.putObject("Asset", asset);
                window.location.reload();
            };


        }
    }

);