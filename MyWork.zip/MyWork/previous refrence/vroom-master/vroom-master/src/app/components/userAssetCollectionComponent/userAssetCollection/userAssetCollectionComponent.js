var astColl = angular.module("userApp");

astColl.component('assetCollection', {
    transclude: true,
    bindings: {
        assets: '='
    },
    templateUrl: 'app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollection.html',
    controller: function(assetCollectionGalleryService, $cookies) {

        this.assetInfo = function(asset) {
            console.log(asset);
            $cookies.putObject("Asset", asset);
        }

        var userMid = $cookies.get("userMid").toString();
        this.menuarray = [];


        var self = this;
        assetCollectionGalleryService.getAssets().then(function successCallback(response) {
            self.assets = response.data;
        }, function errorCallback(response) {
            //self.assets = "Error: " + response.statusText;
        });
        assetCollectionGalleryService.getRoomDesigns().then(function successCallback(response) {

            self.roomDesigns = response.data;
        }, function errorCallback(response) {
            //self.roomDesigns = "Error: " + response.statusText;
        });




        assetCollectionGalleryService.getFavs({ "MID": userMid }).then(function successCallback(response) {
            console.log(response.data);
            self.favs = response.data;
        }, function errorCallback(response) {
            //self.favs = "Error: " + response.statusText;
        });






        this.showassetphotos = function(x) {
            var count = 0;
            var roomselcount = 0;
            if (this.menuarray.length === 0)
                return false;
            for (var i1 = 0; i1 < this.menuarray.length; i1++) {
                roomselcount = 0;
                for (var j1 = 0; j1 < this.menuarray[i1].length; j1++)
                    if (!this.menuarray[i1][j1].checked)
                        roomselcount++;
                if (roomselcount === this.menuarray[i1].length) {
                    // console.log("entering category");
                    for (var k1 = 0; k1 < x.assetCategory.length; k1++) {
                        if (x.assetCategory[k1] == this.menuarray[i1].heading)
                            return false;
                    }
                }
            }

            for (var i = 0; i < this.menuarray.length; i++)
                for (var j = 0; j < this.menuarray[i].length; j++) {

                    // console.log(this.menuarray.length, this.menuarray[i].length);
                    // console.log(this.menuarray[i][j].name);
                    // console.log(this.menuarray[i][j].checked);

                    if (this.menuarray[i][j].checked == true) {
                        // console.log("entering the selected menu")
                        for (var k = 0; k < x.assetRoomType.length; k++) {
                            if (x.assetRoomType[k] == this.menuarray[i][j].name)
                                count++;
                        }
                    }


                }
                // console.log(count);
            if (count > 0)
                return false;
            else
                return true;

        };
        this.showroomphotos = function(x) {
            var count = 0;
            var roomselcount = 0;
            if (this.menuarray.length === 0)
                return false;
            for (var i1 = 0; i1 < this.menuarray.length; i1++) {
                roomselcount = 0;
                for (var j1 = 0; j1 < this.menuarray[i1].length; j1++)
                    if (!this.menuarray[i1][j1].checked)
                        roomselcount++;
                if (roomselcount === this.menuarray[i1].length) {
                    // console.log("entering category");
                    for (var k1 = 0; k1 < x.roomCategory.length; k1++) {
                        if (x.roomCategory[k1] == this.menuarray[i1].heading)
                            return false;
                    }
                }
            }

            for (var i = 0; i < this.menuarray.length; i++)
                for (var j = 0; j < this.menuarray[i].length; j++) {

                    // console.log(this.menuarray.length, this.menuarray[i].length);
                    // console.log(this.menuarray[i][j].name);
                    // console.log(this.menuarray[i][j].checked);

                    if (this.menuarray[i][j].checked == true) {
                        // console.log("entering the selected menu")
                        for (var k = 0; k < x.roomTypeName.length; k++) {
                            if (x.roomTypeName[k] == this.menuarray[i][j].name)
                                count++;
                        }
                    }


                }
                // console.log(count);
            if (count > 0)
                return false;
            else
                return true;

        };
    }

});






















// astColl.directive('assetCollection', function() {
//     return {
//         restrict: 'A',
//         templateUrl: 'app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollection.html',
//         controller: ['$scope', 'assetCollectionGalleryService', function assetCollectionGalleryController($scope, assetCollectionGalleryService) {


//             assetCollectionGalleryService.assets(function(res) {
//                 console.log(res);
//                 $scope.assets = res;
//             });

//             assetCollectionGalleryService.categories(function(res) {
//                 console.log(res);
//                 $scope.categories = res;

//             });

//             // var cat = assetCollectionGalleryService.rooms();
//             // cat.then(function(response) {
//             //     $scope.rooms = response;
//             // })





//             assetCollectionGalleryService.rooms().then(function(response) {
//                 $scope.rooms = response;
//             });









//             // assetCollectionGalleryService.rooms(function(assetCollectionGalleryService) {

//             //     $scope.rooms = assetCollectionGalleryService;
//             // });


//             // $scope.assets = assetCollectionGalleryService.assets;
//             // // $scope.categories = assetCollectionGalleryService.categories;
//             // $scope.rooms = function() {
//             //     assetCollectionGalleryService.rooms.then(function(data) {
//             //         console.log(data + "in ctrl");
//             //         $scope.rooms = data;
//             //     });
//             // }
//         }]
//     };
// });