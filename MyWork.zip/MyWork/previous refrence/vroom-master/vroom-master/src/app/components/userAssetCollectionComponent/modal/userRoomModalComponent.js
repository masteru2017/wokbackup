var modal = angular.module("userApp");

modal.component('usermodalComponent', {
    require: {
        parent: '^assetCollection'
    },
    templateUrl: 'app/components/userAssetCollectionComponent/modal/userRoomModalWindow.html',
    controller: function(modalService, $cookies, $state) {
        var self = this;
        self.mid = [$cookies.get("userMid")];

        self.roomdetails = {};
        console.log("heyyy");
        // self.$onInit = function() {
        //     self.parent.designName = this.designName;
        //     self.parent.designAccess = this.designAccess;
        // };
        // self.Save = function() {
        //     console.log("this design name ", self.designName);
        //     console.log("this design access ", self.designAccess);
        //     this.parent.getData(this.designName, this.designAccess);
        // };
        // self.down = function() {
        //     this.parent.download();
        // };

        self.savedDesigns = [];
        self.redirect="";
        self.choose = function() {
            console.log(self.design);
            if (self.design == "New Design") {
                self.redirect="userDesign";
                // document.getElementById("choose").style.visibility = "hidden";
                // document.getElementById("m2").style.visibility = "hidden";
                // document.getElementById("m2").style.visibility = "visible";


                // document.getElementById("newSelect").style.display = "block";
                // console.log($cookies.getObject("Asset").roomCategory);
                self.flag1 = true;
                self.flag2 = false;
                self.room = $cookies.getObject("Asset");
                console.log(self.room);
                self.rooms = $cookies.getObject("Asset").roomCategory;
                self.themes = $cookies.getObject("Asset").roomTheme;
                self.types = $cookies.getObject("Asset").roomTypeName;
                console.log(self.selectedName);
            }
            if (self.design == "Saved Design") {
                // document.getElementById("choose").style.visibility = "hidden";
                // document.getElementById("saved").style.display = "block";
                self.redirect="editDesign"
                self.flag2 = true;
                self.flag1 = false;
                modalService.getDesigns(self.mid).then(function successCallback(response) {
                    // console.log(response.data);


                    for (i = 0; i < response.data.length; i++) {

                        self.savedDesigns[i] = response.data[i].designName;
                        // if(response.data[i].designName==)
                    }
                    console.log(self.savedDesigns);
                    // console.log(response.data[0].designName);
                    // self.savedDesigns = response.data;
                }, function errorCallback(response) {
                    self.savedDesigns = "Error: " + response.statusText;
                });
            }

        };


        self.design1 = function() {
            modalService.getDesigns(self.mid).then(function successCallback(response) {
                console.log(response.data);


                for (i = 0; i < response.data.length; i++) {
                    if (response.data[i].designName == self.selectedSaved) {
                        self.selectedDesignObject = response.data[i];
                        // $cookies.putObject("selectedDesignObject", self.selectedDesignObject);
                        console.log("yheyyy");
                        console.log(self.selectedDesignObject);
                        $cookies.putObject("DesignObject", self.selectedDesignObject);
                    }
                }
                // console.log(self.savedDesigns);
                // console.log(response.data[0].designName);
                // self.savedDesigns = response.data;
            }, function errorCallback(response) {
                self.savedDesigns = "Error: " + response.statusText;
            });

            // console.log("yoyyo");
            // console.log(self.selectedDesignObject);

        }

        self.details = function() {
            if (self.design == "New Design") {
                console.log(self.selectedCategory);
                console.log(self.selectedTheme);
                console.log(self.selectedType);
                self.roomdetails = {
                    category: self.selectedCategory,
                    theme: self.selectedTheme,
                    type: self.selectedType
                };
                // console.log(self.details);
                modalService.setDetails(self.roomdetails, self.room);
                modalService.getDetails();

                $cookies.putObject("details", self.roomdetails);
                $cookies.putObject("roomObject", self.room);
                $cookies.remove("DesignObject");
                // console.log($cookies.getObject("details"));
            }
            if (self.design == "Saved Design") {
                self.selectedDesign = self.selectedSaved;
                console.log(self.selectedSaved);
            }
            $state.go(self.redirect);
        }
    }
});