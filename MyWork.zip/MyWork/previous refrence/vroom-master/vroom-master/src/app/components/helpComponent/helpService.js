helpCmp.factory('helpService', function($http) {
    return {
        getFaqCollection: function() {
            // return $http({ method: 'GET', url: "assets/data/faq.json" });
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/faq');
        }
    };
});