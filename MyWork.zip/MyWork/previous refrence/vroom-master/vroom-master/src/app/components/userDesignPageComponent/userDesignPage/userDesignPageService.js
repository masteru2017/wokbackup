userDesignCmp.factory('userDesignService', function($http, $cookies) {
    return {
        getMid: function() {
            return $cookies.get('userMid');
        },
        getRoomTypeCollection: function() {
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/roomTypeData');
        },
        getAssetCollection: function() {
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/assetCollectionData');
        },
        getFavAssetData: function(mid) {
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/getAssetData', mid);
        },
        setUserDesign: function(mid) {
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/setUserDesign', mid);
        }
    };
});