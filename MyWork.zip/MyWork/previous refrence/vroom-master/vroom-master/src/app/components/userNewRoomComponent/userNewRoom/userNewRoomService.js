userRoomCmp.factory('userRoomService', function($http, $cookies) {
    var selectedRoom = "";
    var getRoom = function() {
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/roomData');
    };


    // function setSelectedRoom(val) {
    //     selectedRoom = val;
    //     console.log("ROOM" + selectedRoom);
    // }

    function getSelectedRoom() {
        // return selectedRoom;
        return ($cookies.get("Room"));
    }


    return {
        // setSelectedRoom: setSelectedRoom,
        getSelectedRoom: getSelectedRoom,
        getRoom: getRoom
    };


});