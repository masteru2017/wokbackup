modal.factory("modalService", function($http, $cookies) {

    var roomDetails = "";
    var room = "";
    return {
        setDetails: function(details, rooms) {
            roomDetails = details;
            room = rooms;
        },
        getDetails: function() {

            return { roomDetails, room };


        },
        getDesigns: function(mid) {
            console.log(mid);
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/getDesignData', mid);
        }

    }

});