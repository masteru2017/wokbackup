var helpCmp = angular.module('userApp');


function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


helpCmp.component('helpComponent', {
    transclude: true,

    templateUrl: 'app/components/helpComponent/helpPage.html',
    controller: function($http, helpService) {
        self = this;
        this.c = 0;
        this.homes = [];
        this.creates = [];
        this.edits = [];
        this.assets = [];



        helpService.getFaqCollection().then(function successCallback(response) {
            self.faqs = response.data;

            for (var i1 = 0; i1 < 4; i1++) {
                self.homes[i1] = self.faqs[self.c];
                self.c++;
            }

            for (var i2 = 0; i2 < 4; i2++) {
                self.creates[i2] = self.faqs[self.c];
                self.c++;
            }

            for (var i3 = 0; i3 < 4; i3++) {
                self.edits[i3] = self.faqs[self.c];
                self.c++;
            }

            for (var i4 = 0; i4 < 4; i4++) {
                self.assets[i4] = self.faqs[self.c];
                self.c++;
            }


        }, function errorCallback(response) {
            self.faqs = "Error: " + response.statusText;
        });



        this.logout = function() {
            adalAuthenticationService.logOut();
        };

    }
});