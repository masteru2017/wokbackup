var svdFilterCmp = angular.module("userApp");
svdFilterCmp.component('savedFilters', {

    require: {
        alpha: '^savedDesign'
    },
    bindings: {
        categories: '=',
        rooms: '='
    },
    templateUrl: 'app/components/userSavedDesignComponent/userSavedFilters/userSavedFilters.html',
    controller: function(userSavedFiltersService) {
        this.$onInit = function() {
            // console.log("yooyy");
            // console.log("userFilterController");
            // console.log(this);
            // console.log('parent of controller is');
            // console.log(this.parent);

            var self = this;
            self.hotel = null;
            userSavedFiltersService.getCategories().then(function successCallback(response) {
                self.categories = response.data;

            }, function errorCallback(response) {
                self.categories = "Error: " + response.statusText;
            });
            // userSavedFiltersService.getRooms().then(function successCallback(response) {
            //     self.rooms = response.data;
            // }, function errorCallback(response) {
            //     self.rooms = "Error: " + response.statusText;
            // });
            userSavedFiltersService.hotelRooms().then(function successCallback(response) {
                self.hotelrooms = response.data;
                self.hotel = self.hotelrooms;

            }, function errorCallback(response) {
                self.hotelrooms = "Error: " + response.statusText;
            });
            userSavedFiltersService.homeRooms().then(function successCallback(response) {
                self.homerooms = response.data;
            }, function errorCallback(response) {
                self.homerooms = "Error: " + response.statusText;
            });
            userSavedFiltersService.salonRooms().then(function successCallback(response) {
                self.salonrooms = response.data;
            }, function errorCallback(response) {
                self.salonrooms = "Error: " + response.statusText;
            });


            // console.log(userSavedFiltersService.homeRooms().then());



            this.assets = userSavedFiltersService.assets;
            this.categories = userSavedFiltersService.categories;
            this.homerooms = userSavedFiltersService.homerooms;

            this.hotelrooms = userSavedFiltersService.hotelrooms;
            this.salonrooms = userSavedFiltersService.salonrooms;
            this.menuarray = [];
            // this.showphotos = function(x) {
            //     console.log(x.assetRoomType)
            //     for (var i = 0; i < this.menuarray.length; i++)
            //         for (var j = 0; j < this.menuarray[i].length; j++) {
            //             console.log(this.menuarray[i][j].name)
            //             console.log(this.menuarray[i][j].checked)

            //             if (this.menuarray[i][j].checked) {
            //                 for (var k = 0; k < x.assetRoomType.length; k++) {
            //                     if (x.assetRoomType[k] == this.menuarray[i][j].name)
            //                         return true;
            //                 }
            //             }
            //         }

            //     return false;
            // }
            this.roomselection = function(x, y) {
                // console.log(x, y);
            };

            this.categoryselection = function(x, y) {
                // console.log(x, y);
                if (y == true) {
                    if (x == "Home") {
                        this.menuarray.push(this.homerooms);
                        this.menuarray[this.menuarray.length - 1].heading = x;
                    } else if (x == "Hotel") {
                        this.menuarray.push(this.hotelrooms);
                        this.menuarray[this.menuarray.length - 1].heading = x;
                    } else if (x == "Salon")
                        this.menuarray.push(this.salonrooms);
                    this.menuarray[this.menuarray.length - 1].heading = x;
                }
                if (y == false) {
                    for (var i = 0; i < this.menuarray.length; i++) {
                        if (this.menuarray[i].heading == x) {
                            this.menuarray.splice(i, 1);
                        }
                    }
                }
                // console.log(this.menuarray);
                this.alpha.menuarray = this.menuarray;



                // console.log("parent menuarray");
                // console.log(this.parent.menuarray);

            }












        }
    }

})