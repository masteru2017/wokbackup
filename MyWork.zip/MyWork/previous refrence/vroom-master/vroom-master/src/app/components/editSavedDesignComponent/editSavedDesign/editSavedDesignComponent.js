var editDesignCmp = angular.module('userApp');

editDesignCmp.component('editDesign', {
    templateUrl: 'app/components/editSavedDesignComponent/editSavedDesign/editSavedDesign.html',
    controller: function(userSavedDesignGalleryService,userCategoryService,$state, $http, editDesignService, $cookies, userDesignService) {
        console.log(userSavedDesignGalleryService.getEditDesignRoom());
        var design = userSavedDesignGalleryService.getEditDesignRoom();
        var assets = design.designAssets;
        var self = this;

        self.c = design.designRoom.roomCategory;
        self.t = design.designRoom.roomTheme;
        self.r = design.designRoom.roomTypeName;

        self.roomData = [];
        self.assetData = [];
        self.favData = [];

        var userMid = $cookies.get("userMid").toString();
         userDesignService.getFavAssetData({ "MID": userMid }).then(function successCallback(response) {
            self.favData = response.data;
        }, function errorCallback(response) {
            self.favData = "Error: " + response.statusText;
        });

        editDesignService.getRoomTypeCollection().then(function successCallback(response) {
                console.log("wassup");
                for (var i = 0; i < response.data.length; i++) {
                    var count = 0;
                    for (var j = 0; j < response.data[i].roomTypeName.length; j++) {
                        for (var a = 0; a < self.r.length; a++) {
                            if (response.data[i].roomTypeName[j] === self.r[a]) {
                                count++;
                                break;
                            }
                        }
                    }

                    for (j = 0; j < response.data[i].roomCategory.length; j++) {
                        for (var b = 0; b < self.c.length; b++) {
                            if (response.data[i].roomCategory[j] === self.c[b]) {
                                count++;
                                break;
                            }
                        }
                    }

                    for (j = 0; j < response.data[i].roomTheme.length; j++) {
                        for (var c = 0; c < self.t.length; c++) {
                            if (response.data[i].roomTheme[j] === self.t[c]) {
                                count++;
                                break;
                            }
                        }
                    }

                    if (count >= 3) {
                        self.roomData.push(response.data[i]);
                        console.log("roomdata", self.roomData);
                    }

                }
            },
            function errorCallback(response) {
                self.roomData = "Error: " + response.statusText;
            });


        console.log("self.r", self.r);
        console.log("self.t", self.t);
        console.log("self.c", self.c);


        document.getElementById("myCanvas").onmouseenter = function() { disableScroll(); };
        document.getElementById("myCanvas").onmouseleave = function() { enableScroll(); };
        //-----------getting Assets-------------------------------

        editDesignService.getAssetCollection().then(function successCallback(response) {
            console.log("wassup asset");
            for (var i = 0; i < response.data.length; i++) {
                var count = 0;
                for (var j = 0; j < response.data[i].assetRoomType.length; j++) {
                    for (var a = 0; a < self.r.length; a++) {
                        if (response.data[i].assetRoomType[j] === self.r[a]) {
                            count++;
                        }
                    }
                }

                for (j = 0; j < response.data[i].assetCategory.length; j++) {
                    for (var b = 0; b < self.c.length; b++) {
                        if (response.data[i].assetCategory[j] === self.c[b]) {
                            count++;
                        }
                    }
                }

                for (j = 0; j < response.data[i].assetTheme.length; j++) {
                    for (var c = 0; c < self.t.length; c++) {
                        if (response.data[i].assetTheme[j] === self.t[c]) {
                            count++;
                        }
                    }
                }

                if (count >= 0) {
                    self.assetData.push(response.data[i]);

                }
            }

            console.log("assetsstststststststst", self.assetData);
        }, function errorCallback(response) {
            self.assetData = "Error: " + response.statusText;
        });


        //--------------------initiation of canvas---------------

        var dir = 1;
        var ang = 0;
        var undoState;
        var myState;
        var isDown = false;
        var isLeft = false;
        var isRight = false;
        var isTop = false;
        var isBottom = false;
        var iAnchor;
        var border = 10;
        var iLeft, iTop, iRight, iBottom, iOrientation, iH, iW;
        var canvasImages = [];


        self.init = function() {

            console.log("start image");
            var s = new CanvasState(document.getElementById("myCanvas"));
            var i = new Image();
            i.src = design.designRoom.roomUrl;
            canvasImages[0] = design.designRoom._id;
            s.addImage(new ImageShape(i, 0, 0, 1024, 600));
            console.log("assets length", assets.length);
            for (var j = 0; j < assets.length; j++) {
                canvasImages.push(assets[j].asset._id);
                i = new Image();
                i.src = assets[j].asset.assetUrl;
                var ix = assets[j].position.coordinates[0];
                var iy = assets[j].position.coordinates[1];
                var iw = assets[j].position.scaling[0];
                var ih = assets[j].position.scaling[1];
                var ir = assets[j].position.rotation;
                s.addImage(new ImageShape(i, ix, iy, iw, ih, ir));

            }

        };

        //--------------------creating saved design object to push in collection------------------------------
        self.getData = function(dName, dAccess) {

            console.log("canvasIMages:", canvasImages);

            console.log(myState.images.length);
            console.log(self.assetData.length);
            console.log(self.assetData[0].assetUrl);
            // console.log(myState.images[1].i.src.split('90/')[1]);
            var assetsArray = [];
            var room;
            for (var j = 0; j < self.roomData.length; j++) {
                if (canvasImages[0] === self.roomData[j]._id) {
                    // console.log("room ", self.roomData[j]);
                    room = self.roomData[j];
                    console.log("Room object ", room);
                    break;
                }
            }
            for (var c = 1; c < myState.images.length; c++) {
                console.log("loop1");
                // console.log(myState.images[i]);
                for (var j = 0; j < self.assetData.length; j++) {
                    console.log("loop2");
                    if (canvasImages[c] === self.assetData[j]._id) {
                        // console.log("asset url", self.assetData[j].assetUrl);
                        assetsArray.push({
                            "asset": self.assetData[j],
                            "position": {
                                "coordinates": [myState.images[c].x, myState.images[c].y],
                                "scaling": [myState.images[c].w, myState.images[c].h],
                                "rotataion": myState.images[c].r
                            }
                        });
                        break;

                    }
                }
            }
            console.log("asset ", assetsArray);
            console.log("asset length", assetsArray.length);
            var monthNames = [
                "Jan", "Feb", "Mar",
                "Apr", "May", "Jun", "Jul",
                "Aug", "Sep", "Oct",
                "Nov", "Dec"
            ];


            var date = new Date();
            var day = date.getDate();
            var monthIndex = date.getMonth();
            var year = date.getFullYear();
            var today = monthNames[monthIndex] + ' ' + day + ', ' + year;
            console.log('today ', today);
            var design = {
                "designEditable": "true",
                "designAccess": dAccess,
                "designName": dName,
                "designDate": today,
                "designRoom": room,
                "designAssets": assetsArray
            };
            console.log("Design obj: ", design);
            console.log(dName);
            var mid = [userDesignService.getMid(), design];
            // userDesignService.setUserDesign(mid);
            userSavedDesignGalleryService.replaceEditedDesign(mid);
        };

        self.delAsset = function() {
            if (myState.selection !== null) {
                myState.images.splice(myState.selImageIndex, 1);
                canvasImages.splice(myState.selImageIndex, 1);
                myState.valid = false;
                myState.selection = null;
                myState.draw();
            }
        };


        //----------------change background on canvas------------

        self.changeBg = function(newBgUrl, id) {
            var i = new Image();
            i.src = newBgUrl;
            canvasImages[0] = id;
            myState.images[0] = new ImageShape(i, 0, 0, 1024, 600);
            myState.valid = false;
            myState.draw();
        };

        //-------------add assets on canvas--------------

        self.addAsset = function(assetUrl, id) {
            var i = new Image();
            i.src = assetUrl;
            canvasImages.push(id);
            myState.images.push(new ImageShape(i, 0, 0, 120, 150, 0));
            myState.valid = false;
            myState.draw();

        };

        var flip = 1;
        self.flipImage = function() {
            // dir = 2;
            flip = -1 * flip;
            // console.log("state", myState);
            // console.log("selection:", myState.selection);
            if (myState.selection !== null) {
                myState.valid = false;
                myState.flipping = true;
                myState.draw();
            } else {
                myState.rotating = false;
            }
        };


        self.rotImageR = function() {
            dir = 1;
            // console.log("state", myState);
            // console.log("selection:", myState.selection);
            if (myState.selection !== null) {
                myState.valid = false;
                myState.rotating = true;
                myState.draw();
            } else {
                myState.rotating = false;
            }
            // console.log("rotate :" + myState.rotating);
        }

        self.rotImageL = function() {
                dir = -1;
                // console.log("state", myState);
                // console.log("selection:", myState.selection);
                if (myState.selection !== null) {
                    myState.valid = false;
                    myState.rotating = true;
                    myState.draw();
                } else {
                    myState.rotating = false;
                }
                // console.log("rotate :" + myState.rotating);
            }
            //----------------------------------------------------------------------------------------------

        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });


        //-------------------------save canvas---------------------
        var redirect = false;
        self.download = function() {
            var canvas = document.getElementById("myCanvas");
            var image = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"); //Convert image to 'octet-stream' (Just a download, really)
            var imageUrl = canvas.toDataURL("image/png");
            // console.log("saved image url", imageUrl);
            window.location.href = image;
             redirect = true;
        }
        setInterval(
            function() {
                if (redirect) {
                    $state.go('userSavedDesign');
                    redirect = false;
                }
            }, 3000);
        //----------------canvas state-----------------------------------//

        // initializing canvas for each images


        function CanvasState(canvas) {

            this.canvas = canvas;
            this.width = canvas.width;
            this.height = canvas.height;
            this.ctx = canvas.getContext('2d');

            var stylePaddingLeft, stylePaddingTop, styleBorderLeft, styleBorderTop;
            if (document.defaultView && document.defaultView.getComputedStyle) {
                this.stylePaddingLeft = parseInt(document.defaultView.getComputedStyle(canvas, null)['paddingLeft'], 10) || 0;
                this.stylePaddingTop = parseInt(document.defaultView.getComputedStyle(canvas, null)['paddingTop'], 10) || 0;
                this.styleBorderLeft = parseInt(document.defaultView.getComputedStyle(canvas, null)['borderLeftWidth'], 10) || 0;
                this.styleBorderTop = parseInt(document.defaultView.getComputedStyle(canvas, null)['borderTopWidth'], 10) || 0;
            }

            var html = document.body.parentNode;
            this.htmlTop = html.offsetTop;
            this.htmlLeft = html.offsetLeft;

            this.valid = false; // when set to false, the canvas will redraw everything
            this.dragging = false; // Keep track of when we are dragging
            this.resizing = false; //keep track of resizing event
            this.rotating = false; //keep track of rotating event
            this.flipping = false; //keep track of flipping event

            // the current selected object. In the future we could turn this into an array for multiple selection
            this.selection = null;
            this.dragoffx = 0; // See mousedown and mousemove events for explanation
            this.dragoffy = 0;

            this.images = []; // the collection of images to be drawn

            myState = this;
            this.selImageIndex = -1;

            //fixes a problem where double clicking causes text to get selected on the canvas
            canvas.addEventListener('selectstart', function(e) {
                e.preventDefault();
                return false;
            }, false);

            // Up, down, and move are for dragging
            canvas.addEventListener('mousedown', function(e) {

                e.preventDefault();
                e.stopPropagation();
                var mouse = myState.getMouse(e);
                var mx = mouse.x;
                var my = mouse.y;
                var images = myState.images;
                var l = images.length;
                var mySel;
                //-----------get selected image--------------------------
                for (var i = l - 1; i > 0; i--) {
                    var canvas = document.getElementById("myCanvas");
                    if (images[i].contains(mx, my)) {
                        window.addEventListener('keydown', doKeyDown, true);
                        mySel = images[i];
                        myState.selImageIndex = i;

                        iLeft = mySel.x;
                        iTop = mySel.y;
                        iBottom = mySel.y + mySel.h;
                        iRight = mySel.x + mySel.w;
                        iOrientation = (mySel.w >= mySel.h) ? "Wide" : "Tall";
                        iH = mySel.h;
                        iW = mySel.w;
                        iAnchor = hitResizeAnchor(mx, my);
                        // console.log(iAnchor);
                        isDown = (iAnchor);

                        myState.selection = mySel;
                        myState.valid = false;
                        //--------------check for resize ----------------------------
                        if (iAnchor !== null) {
                            myState.valid = true;
                            myState.resizing = true;
                        }
                        //--------------------check for drag event-----------------------
                        if (!myState.resizing) {
                            myState.dragoffx = mx - mySel.x;
                            myState.dragoffy = my - mySel.y;
                            myState.dragging = true;
                        }
                        //............checking for mousewheel up and down.......................
                        if (myState.resizing === false) {
                            disableScroll();
                            canvas.addEventListener("mousewheel", function(e) {
                                if (e.deltaY > 0) {
                                    if (myState.selection.h < 1024 && myState.selection.w < 600) {
                                        myState.selection.h += 1;
                                        myState.selection.w += 1;
                                        myState.valid = false;
                                        myState.draw();
                                    }


                                } else if (e.deltaY < 0) {
                                    if (myState.selection.h > 20 && myState.selection.w > 20) {
                                        myState.selection.h -= 1;
                                        myState.selection.w -= 1;
                                        // mySel.h = mySel.h - 1;
                                        // mySel.w = mySel.w - 1;
                                        myState.valid = false;
                                        myState.draw();

                                    }
                                }

                                return;

                            });

                        }

                        return;

                    } else
                        window.removeEventListener('keydown', doKeyDown, true);
                }
                // havent returned means we have failed to select anything.
                // If there was an object selected, we deselect it
                if (myState.selection) {
                    myState.selection = null;
                    myState.valid = false; // Need to clear the old selection border
                }
            }, true);



            //------------adding key events------------------


            function doKeyDown(e) {
                var dy = 1;
                var dx = 1;

                console.log("key pressed");
                e.preventDefault();
                switch (e.keyCode) {
                    case 38:
                    case 87:
                        /* Up arrow was pressed */
                        if (myState.selection.y - dy > 0) {
                            console.log("  up");
                            console.log(dy);
                            console.log(myState.selection.y);
                            myState.selection.y -= dy;
                            myState.images[myState.selImageIndex].draw();
                            myState.valid = false;
                        }
                        break;
                    case 40:
                    case 83:
                        /* Down arrow was pressed */
                        if (myState.selection.y + dy < 570) {
                            console.log("down");
                            myState.selection.y += dy;
                            myState.images[myState.selImageIndex].draw();
                            myState.valid = false;
                        }
                        break;
                    case 37:
                    case 65:
                        /* Left arrow was pressed */
                        if (myState.selection.x - dx > 0) {
                            console.log("left");
                            console.log(myState.selection.x);
                            myState.selection.x -= dx;
                            myState.images[myState.selImageIndex].draw();
                            myState.valid = false;
                        }
                        break;
                    case 39:
                    case 68:
                        /* Right arrow was pressed */
                        if (myState.selection.x + dx < 1000) {
                            console.log("right");
                            myState.selection.x += dx;
                            myState.images[myState.selImageIndex].draw();
                            myState.valid = false;
                        }
                        break;

                    case 69:
                        self.rotImageR();
                        break;
                    case 81:
                        self.rotImageL();
                        break;
                    default:

                        break;

                }
            }


            canvas.addEventListener('mousemove', function(e) {


                var mouse = myState.getMouse(e);
                e.preventDefault();
                e.stopPropagation();
                if (myState.dragging) {

                    // We don't want to drag the object by its top-left corner, we want to drag it
                    // from where we clicked. Thats why we saved the offset and use it here
                    myState.selection.x = mouse.x - myState.dragoffx;
                    myState.selection.y = mouse.y - myState.dragoffy;
                    myState.valid = false; // Something's dragging so we must redraw
                }

                //--------------------------------resize---------------------------

                if (myState.resizing) {
                    // return if we're not dragging
                    if (!isDown) {
                        return;
                    }
                    // get MouseX/Y
                    var mouseX = mouse.x;
                    var mouseY = mouse.y;
                    // reset iLeft,iRight,iTop,iBottom based on drag
                    resizeFunctions[iAnchor](mouseX, mouseY);
                    myState.valid = false;
                }
            }, true);


            canvas.addEventListener('mouseup', function(e) {
                e.preventDefault();
                e.stopPropagation();

                myState.dragging = false;
                //------------------------resize---------------------------
                myState.resizing = false;

                isDown = false;
            }, true);

            this.selectionColor = '#000000';
            this.selectionWidth = 1;
            this.interval = 30;
            setInterval(function() {
                myState.draw();
            }, myState.interval);


        }

        CanvasState.prototype.addImage = function(image) {
            this.images.push(image);
            this.valid = false;
        };


        CanvasState.prototype.clear = function() {
            this.ctx.clearRect(0, 0, this.width, this.height);
        };

        CanvasState.prototype.draw = function() {

            // if our state is invalid, redraw and validate!
            if (!this.valid) {
                var ctx = this.ctx;
                var images = myState.images;
                myState.clear();
                // ** Add stuff you want drawn in the background all the time here **
                // draw all images
                // console.log(myState.selImageIndex);
                var l = images.length;
                // console.log(l + "=length");
                for (var i = 0; i < l; i++) {
                    myState.ctx.save();
                    var image = images[i];

                    // We can skip the drawing of elements that have moved off the screen:
                    if (image.x > this.width || image.y > this.height || image.x + image.w < 0 || image.y + image.h < 0)
                        continue;

                    if ((myState.rotating || myState.resizing || myState.flipping) && myState.selection !== null && !myState.dragging) {
                        if (myState.selImageIndex !== i) {
                            images[i].draw();
                        }

                    } else {
                        images[i].draw();
                    }
                }
                if ((myState.rotating || myState.flipping) && !myState.resizing && myState.selection !== null && !myState.dragging && myState.selImageIndex !== 0) {
                    if (myState.flipping)
                        dir = 2;
                    if (dir === 1)
                        myState.selection.r += 10;
                    if (dir === -1)
                        myState.selection.r -= 10;

                    images[myState.selImageIndex].draw();
                    myState.rotating = false;
                    myState.flipping = false;

                }
                if (myState.resizing && !myState.rotating && myState.selection !== null && !myState.dragging && myState.selImageIndex !== 0) {
                    myState.selection.x = iLeft;
                    myState.selection.y = iTop;
                    myState.selection.w = iRight - iLeft;
                    myState.selection.h = iBottom - iTop;
                    images[myState.selImageIndex].draw();
                }
                // draw selection
                // right now this is just a stroke along the edge of the selected image

                if (myState.selection !== null) {
                    ctx.strokeStyle = this.selectionColor;
                    ctx.lineWidth = this.selectionWidth;
                    var mySel = this.selection;
                    var border = 10;
                    ctx.strokeRect(mySel.x, mySel.y, mySel.w, mySel.h);

                    //---------resizing pointers--------------------------------------
                    ctx.fillRect(mySel.x, mySel.y, border, border);
                    ctx.fillRect(mySel.x + mySel.w / 2, mySel.y, border, border);
                    ctx.fillRect(mySel.x + mySel.w - 10, mySel.y, border, border);

                    ctx.fillRect(mySel.x, mySel.y + mySel.h / 2, border, border);
                    ctx.fillRect(mySel.x + mySel.w - 10, mySel.y + mySel.h / 2, border, border);

                    ctx.fillRect(mySel.x, mySel.y + mySel.h - 10, border, border);
                    ctx.fillRect(mySel.x + mySel.w / 2, mySel.y + mySel.h - 10, border, border);
                    ctx.fillRect(mySel.x + mySel.w - 10, mySel.y + mySel.h - 10, border, border);

                    //--------------------------rotating pointers----------------------------------
                    // ctx.translate(mySel.x + mySel.w / 2, mySel.y + mySel.h / 2);
                    // ctx.rotate(3.1415 / 180 * mySel.r);

                    // ctx.fillRect(mySel.w / 2 - mySel.w, mySel.h / 2 - mySel.h, border, border);
                    // ctx.fillRect(0, mySel.h / 2 - mySel.h, border, border);
                    // ctx.fillRect(mySel.w / 2 - 10, mySel.h / 2 - mySel.h, border, border);

                    // ctx.fillRect(mySel.w / 2 - mySel.w, 0, border, border);
                    // ctx.fillRect(mySel.w / 2 - 10, 0, border, border);

                    // ctx.fillRect(mySel.w / 2 - mySel.w, mySel.h / 2 - 10, border, border);
                    // ctx.fillRect(0, mySel.h / 2 - 10, border, border);
                    // ctx.fillRect(mySel.w / 2 - 10, mySel.h / 2 - 10, border, border);
                    // ctx.restore();
                }

                this.valid = true;
            }
        };


        // If you wanna be super-correct this can be tricky, we have to worry about padding and borders
        CanvasState.prototype.getMouse = function(e) {
            var element = this.canvas,
                offsetX = 0,
                offsetY = 0,
                mx, my;

            // Compute the total offset
            if (element.offsetParent !== undefined) {
                do {
                    offsetX += element.offsetLeft;
                    offsetY += element.offsetTop;
                } while ((element = element.offsetParent));
            }

            // Add padding and border style widths to offset
            // Also add the <html> offsets in case there's a position:fixed bar
            offsetX += this.stylePaddingLeft + this.styleBorderLeft + this.htmlLeft;
            offsetY += this.stylePaddingTop + this.styleBorderTop + this.htmlTop;

            mx = e.pageX - offsetX;
            my = e.pageY - offsetY;

            // We return a simple javascript object (a hash) with x and y defined
            return {
                x: mx,
                y: my
            };
        };

        //--------------------------------------------------------------------------------

        //-----------------image shape--------------------------------------

        function ImageShape(i, x, y, w, h, r) {
            this.x = x || 0;
            this.y = y || 0;
            this.w = w || 100;
            this.h = h || 100;
            this.i = i;
            this.r = r || 0;
        }

        // Draws this image to a given context
        ImageShape.prototype.draw = function() {
            //----------------draw image while rotating---------------------
            if (dir === 2) {
                console.log("try to flip " + flip);
                myState.ctx.translate(this.x + this.w / 2, this.y + this.h / 2);
                myState.ctx.scale(flip, 1);
                myState.ctx.drawImage(this.i, this.w / 2, this.h / 2, -this.w, -this.h);
                myState.ctx.restore();
                dir = 1;
            } else if (this.r !== 0) {

                myState.ctx.translate(this.x + this.w / 2, this.y + this.h / 2);
                myState.ctx.rotate(3.1415 / 180 * this.r);
                myState.ctx.drawImage(this.i, this.w / 2, this.h / 2, -this.w, -this.h);
                myState.ctx.restore();
            } else {
                myState.ctx.drawImage(this.i, this.x, this.y, this.w, this.h);
            }
        };
        // Determine if a point is inside the image's bounds
        ImageShape.prototype.contains = function(mx, my) {
            // All we have to do is make sure the Mouse X,Y fall in the area between
            // the image's X and (X + Width) and its Y and (Y + Height)
            return (this.x <= mx) && (this.x + this.w >= mx) &&
                (this.y <= my) && (this.y + this.h >= my);
        };

        //--------------------------------------------------------------------------

        //----------------------------resize--------------------------

        //--------------resize logic starts------------------------------------------------------------------


        function hitResizeAnchor(x, y) {
            //  console.log(x + "," + y);
            //  console.log("L:" + iLeft);
            //  console.log("R:" + iRight);
            //  console.log("T:" + iTop);
            //  console.log("B:" + iBottom);
            // which borders are under the mouse
            isLeft = (x > iLeft && x < iLeft + border);
            isRight = (x < iRight && x > iRight - border);
            isTop = (y > iTop && y < iTop + border);
            isBottom = (y < iBottom && y > iBottom - border);

            // return the appropriate anchor
            if (isTop && isLeft) {
                return (iOrientation + "TL");
            }
            if (isTop && isRight) {
                return (iOrientation + "TR");
            }
            if (isBottom && isLeft) {
                return (iOrientation + "BL");
            }
            if (isBottom && isRight) {
                return (iOrientation + "BR");
            }
            if (isTop) {
                return ("T");
            }
            if (isRight) {
                return ("R");
            }
            if (isBottom) {
                return ("B");
            }
            if (isLeft) {
                return ("L");
            }
            return (null);
        }

        var resizeFunctions = {

            T: function(x, y) {
                iTop = y;
            },
            R: function(x, y) {
                iRight = x;
            },
            B: function(x, y) {
                iBottom = y;
            },
            L: function(x, y) {
                iLeft = x;
            },

            WideTR: function(x, y) {
                iRight = x;
                iTop = iBottom - (iH * (iRight - iLeft) / iW);
            },
            TallTR: function(x, y) {
                iTop = y;
                iRight = iLeft + (iW * (iBottom - iTop) / iH);
            },

            WideBR: function(x, y) {
                iRight = x;
                iBottom = iTop + (iH * (iRight - iLeft) / iW);
            },
            TallBR: function(x, y) {
                iBottom = y;
                iRight = iLeft + (iW * (iBottom - iTop) / iH);
            },

            WideBL: function(x, y) {
                iLeft = x;
                iBottom = iTop + (iH * (iRight - iLeft) / iW);
            },
            TallBL: function(x, y) {
                iBottom = y;
                iLeft = iRight - (iW * (iBottom - iTop) / iH);
            },

            WideTL: function(x, y) {
                iLeft = x;
                iTop = iBottom - (iH * (iRight - iLeft) / iW);
            },
            TallTL: function(x, y) {
                iBottom = y;
                iLeft = iRight - (iW * (iBottom - iTop) / iH);
            }
        };

        function draw(withAnchors) {
            var cx = iLeft + (iRight - iLeft) / 2;
            var cy = iTop + (iBottom - iTop) / 2;
            // state.ctx.clearRect(0, 0, 1024, 768);
            state.drawWOR(ndx);
            state.ctx.drawImage(rotateImage.i, iLeft, iTop, iRight - iLeft, iBottom - iTop);
            console.log(rotateImage);
            if (withAnchors) {
                state.ctx.fillRect(iLeft, iTop, border, border);
                state.ctx.fillRect(iRight - border, iTop, border, border);
                state.ctx.fillRect(iRight - border, iBottom - border, border, border);
                state.ctx.fillRect(iLeft, iBottom - border, border, border);
                state.ctx.fillRect(cx, iTop, border, border);
                state.ctx.fillRect(cx, iBottom - border, border, border);
                state.ctx.fillRect(iLeft, cy, border, border);
                state.ctx.fillRect(iRight - border, cy, border, border);
            }
        }


        //............................mousewheel............

        //...................................window scroll off and on...............................

        function disableScroll() {
            if (window.addEventListener) // older FF
                window.addEventListener('DOMMouseScroll', preventDefault, false);
            window.onwheel = preventDefault; // modern standard
            window.onmousewheel = document.onmousewheel = preventDefault; // older browsers, IE
            window.ontouchmove = preventDefault; // mobile

        }

        function enableScroll() {
            if (window.removeEventListener)
                window.removeEventListener('DOMMouseScroll', preventDefault, false);
            window.onmousewheel = document.onmousewheel = null;
            window.onwheel = null;
            window.ontouchmove = null;

        }

        function preventDefault(e) {
            e = e || window.event;
            if (e.preventDefault)
                e.preventDefault();
            e.returnValue = false;
        }




    }
});