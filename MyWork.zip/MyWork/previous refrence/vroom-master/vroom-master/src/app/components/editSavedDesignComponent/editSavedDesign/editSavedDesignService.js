editDesignCmp.factory('editDesignService', function($http, $cookies) {
    return {
        getRoomTypeCollection: function() {
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/roomTypeData');
        },
        getAssetCollection: function() {
            return $http.get('http://digital-coe-api.azurewebsites.net/vroom/assetCollectionData');
        }
    };
});