var userThemeCmp = angular.module('userApp');

userThemeCmp.controller('userThemeController', ['$scope', '$http', 'userCategoryService', 'userThemeService', '$cookies', function($scope, $http, userCategoryService, userThemeService, $cookies) {

    $scope.selCategory = userCategoryService.getSelectedCategory();

    var self = this;

    userThemeService.getTheme().then(function successCallback(response) {
        self.themePanelData = response.data;
    }, function errorCallback(response) {
        // self.themePanelData = "Error: " + response.statusText;
    });

    self.setValue = function(val) {

        console.log(self.themePanelData[val].theme);
        $cookies.put("Theme", self.themePanelData[val].theme);
        // var i = userThemeService.setSelectedTheme(self.themePanelData[val].theme);
    };
}]);

userThemeCmp.component('userThemePanel', {
    bindings: {
        theme: '=',
        function: '='
    },
    templateUrl: 'app/components/userNewThemeComponent/userNewTheme/themeTemplate.html'
});

//------------------directive method--------------------------------------------------------------
// userThemeCmp.directive('userThemePanel', function() {
//     return {
//         restrict: 'A',
//         templateUrl: 'app/components/userNewThemeComponent/userNewTheme/themeTemplate.html'
//     };
// });