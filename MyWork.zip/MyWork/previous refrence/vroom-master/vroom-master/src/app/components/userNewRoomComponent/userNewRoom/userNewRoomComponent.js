var userRoomCmp = angular.module('userApp');

userRoomCmp.controller('userRoomController', ['$scope', '$http', 'userCategoryService', 'userThemeService', 'userRoomService', '$cookies', function($scope, $http, userCategoryService, userThemeService, userRoomService, $cookies) {

    var self = this;
    $scope.selCategory = userCategoryService.getSelectedCategory();
    $scope.selTheme = userThemeService.getSelectedTheme();

    self.theme_name = $scope.selTheme;
    self.roomPanelData = [];

    console.log(userRoomService.getRoom());
    userRoomService.getRoom().then(function successCallback(response) {
            for (var i = 0; i < response.data.length; i++) {
                if (response.data[i].category === $scope.selCategory) {
                    self.roomPanelData.push(response.data[i]);
                }
            }
        },
        function errorCallback(response) {
            // response.data = "Error: " + response.statusText;
        });

    self.set = function(val) {
        console.log(self.roomPanelData[val].room + "--------set room name function");
        $cookies.put("Room", self.roomPanelData[val].room);
        // var i = userRoomService.setSelectedRoom(self.roomPanelData[val].room);
    };

    console.log("userRoomController");
    console.log(this);
}]);

userRoomCmp.component('userRoomPanel', {
    bindings: {
        room: '=',
        set: '=',
        themename: '='
    },
    templateUrl: 'app/components/userNewRoomComponent/userNewRoom/roomTemplate.html'

});

// ----------------using directive------------------------------------------------------
// userRoomCmp.directive('userRoomPanel', function() {
//     return {
//         restrict: 'A',
//         templateUrl: 'app/components/userNewRoomComponent/userNewRoom/RoomTemplate.html',
//     };
// });