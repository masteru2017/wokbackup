var app = angular.module("userApp");

app.component('modalComponent', {
    require: {
        parent: '^userDesign'
    },
    templateUrl: 'app/components/userDesignPageComponent/saveDesignModal/modalWindow.html',
    controller: function() {
        var self = this;
        // self.$onInit = function() {
        //     self.parent.designName = this.designName;
        //     self.parent.designAccess = this.designAccess;
        // };
        self.Save = function() {
            console.log("this design name ", self.designName);
            self.parent.getData(this.designName, this.designAccess);
            self.parent.download();
        };

        // self.imageUrl = this.parent.imageUrl;
        // console.log(self.imageUrl);
    }
});