userThemeCmp.factory('userThemeService', function($http, $cookies) {
    var selectedTheme = "";

    var getTheme = function() {
        return $http.get('http://digital-coe-api.azurewebsites.net/vroom/themeData');
    };

    // function setSelectedTheme(val) {
    //     selectedTheme = val;
    //     console.log(selectedTheme);
    // }

    function getSelectedTheme() {
        // return selectedTheme;
        return ($cookies.get("Theme"));

    }

    return {
        // setSelectedTheme: setSelectedTheme,
        getSelectedTheme: getSelectedTheme,
        getTheme: getTheme
    };

});