  app.component('navComponent', {
      templateUrl: "app/components/common/userNavbar/userNavbarTemplate.html",
      controller: function(adalAuthenticationService, $http) {

          this.$onInit = function() {
              this.logout = function() {
                  adalAuthenticationService.logOut();
              };
              this.userName = "";
              var self = this;
              if (adalAuthenticationService.userInfo && adalAuthenticationService.userInfo.isAuthenticated) {
                  console.log("Authenticated");
                  this.getPhoto = function(adalAuthenticationService) {
                      //   var adal = new AuthenticationContext(adalAuthenticationService.config);
                      //   adal.acquireToken("https://graph.microsoft.com", function(error, token) {

                      //       var request = new XMLHttpRequest();
                      //       request.open("GET", "https://graph.microsoft.com/beta/me/photo/$value");
                      //       request.setRequestHeader("Authorization", "Bearer " + token);

                      //       request.responseType = "blob";
                      //       request.onload = function() {
                      //           if (request.readyState === 4 && request.status === 200) {
                      //               var reader = new FileReader();
                      //               reader.onload = function() {
                      //                   console.log("sending url");
                      //                   //console.log(reader.result);
                      //                   document.getElementById('userImage').src = reader.result;
                      //               };
                      //               reader.readAsDataURL(request.response);
                      //           }
                      //       };
                      //       request.send(null);
                      //   });

                      var photoRequest = {
                          method: 'GET',
                          url: 'https://graph.microsoft.com/v1.0/me/photo/$value',
                          responseType: "blob"
                      };

                      $http(photoRequest)
                          .then(function(response) {
                              console.log(response.data);
                              $log.debug('HTTP request to Microsoft Graph PHOTO API returned successfully.', response);

                              var url = window.URL || window.webkitURL;
                              var blobUrl = url.createObjectURL(response.data);
                              document.getElementById('userImage').src = blobUrl;
                          }, function(error) {
                              console.log('HTTP request to Microsoft Graph API failed.');
                              self.requestSuccess = false;
                              self.requestFinished = true;
                          });

                  };
                  //   console.log(adalAuthenticationService);
                  self.userName = adalAuthenticationService.userInfo.profile.given_name;
                  this.getPhoto(adalAuthenticationService);
              } else {
                  console.log("not authenticated");
              }
          }
      }
  });

  function openNav() {
      document.getElementById("mySidenav").style.width = "250px";
  }

  function closeNav() {
      document.getElementById("mySidenav").style.width = "0";
  }