var savedDesigns = angular.module("userApp");

// savedDesign.controller("userSavedDesignGalleryController", function($scope) {

// });

// savedDesign.directive('userSavedDesignGallery', function() {
//     return {
//         restrict: 'EA',
//         templateUrl: 'app/components/userSavedDesignComponent/userSavedDesign/userSavedDesignGallery.html',
//         controller: ['$scope', 'userSavedDesignGalleryService', function userSavedDesignGalleryController($scope, userSavedDesignGalleryService) {
//             $scope.designs = userSavedDesignGalleryService.designs;
//             $scope.categories = userSavedDesignGalleryService.categories;
//             $scope.rooms = userSavedDesignGalleryService.rooms;
//         }]
//     };
// });



savedDesigns.component('savedDesign', {
    transclude: true,
    bindings: {
        designs: '='
    },
    templateUrl: 'app/components/userSavedDesignComponent/userSavedDesign/userSavedDesignGallery.html',
    controller: function(userSavedDesignGalleryService, $cookies, $state) {
        this.menuarray = [];

        var userMid = $cookies.get("userMid").toString();
        this.selected = "";

        var self = this;

        userSavedDesignGalleryService.getDesigns({ "MID": userMid }).then(function successCallback(response) {
            console.log(response);
            self.designs = response.data;
        }, function errorCallback(response) {
            console.log(response);
        });

        this.showphotos = function(x) {
            var count = 0;
            var roomselcount = 0;
            if (this.menuarray.length === 0)
                return false;
            for (var i1 = 0; i1 < this.menuarray.length; i1++) {
                roomselcount = 0;
                for (var j1 = 0; j1 < this.menuarray[i1].length; j1++)
                    if (!this.menuarray[i1][j1].checked)
                        roomselcount++;
                if (roomselcount === this.menuarray[i1].length) {
                    // console.log("entering category");
                    for (var k1 = 0; k1 < x.assetCategory.length; k1++) {
                        if (x.assetCategory[k1] == this.menuarray[i1].heading)
                            return false;
                    }
                }
            }

            for (var i = 0; i < this.menuarray.length; i++)
                for (var j = 0; j < this.menuarray[i].length; j++) {

                    // console.log(this.menuarray.length, this.menuarray[i].length);
                    // console.log(this.menuarray[i][j].name);
                    // console.log(this.menuarray[i][j].checked);

                    if (this.menuarray[i][j].checked == true) {
                        // console.log("entering the selected menu")
                        for (var k = 0; k < x.assetRoomType.length; k++) {
                            if (x.assetRoomType[k] == this.menuarray[i][j].name)
                                count++;
                        }
                    }
                }
                // console.log(count);
            if (count > 0)
                return false;
            else
                return true;
        };

        self.editDesign = function(design) {
            userSavedDesignGalleryService.setEditDesignRoom(design);
        };

        self.mid = userMid;
        self.deleteDesign = function(design) {
            console.log(self.selected);
            console.log(design);
            var room = design.designName;
            userSavedDesignGalleryService.deleteDesign(room, self.mid);
            
             setTimeout(function(){ location.reload(); }, 3000);
          
        };
    }

});