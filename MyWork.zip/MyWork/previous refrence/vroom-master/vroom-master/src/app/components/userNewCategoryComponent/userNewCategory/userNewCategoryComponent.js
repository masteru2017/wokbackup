var userCatCmp = angular.module('userApp');

userCatCmp.controller('userCategoryController', ['$scope', '$http', 'userCategoryService', '$cookies', function($scope, $http, userCategoryService, $cookies) {
    this.categoryPanelData = [];
    var self = this;
    userCategoryService.getCategory().then(function successCallback(response) {
        self.categoryPanelData = response.data;
        console.log(self.categoryPanelData);
    }, function errorCallback(response) {
        // self.categoryPanelData = "Error: " + response.statusText;
    });


    self.setValue = function(val) {
        console.log(self.categoryPanelData[val].category);
        $cookies.put("Category", self.categoryPanelData[val].category);
        //var i = userCategoryService.setSelectedCategory(self.categoryPanelData[val].category);
    };

}]);


userCatCmp.component('userCategoryPanel', {
    bindings: {
        category: '=',
        function: '='
    },
    templateUrl: 'app/components/userNewCategoryComponent/userNewCategory/categoryTemplate.html',

});