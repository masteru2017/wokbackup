ast.factory("assetGalleryService", function($http) {
    return {

        // getAssets: function() {
        //     return $http({ method: 'GET', url: "assets/data/assetCollection.json" });
        // },
        // getRoomDesigns: function() {
        //     return $http({ method: 'GET', url: "assets/data/roomTypeCollection.json" });
        // }

        sendAsset: function(asset, mid) {
            // console.log("heyy");
            // console.log(asset);
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/assetData', [asset, mid]);

        },

        rmAsset: function(asset, mid) {
            // console.log("rem");
            // console.log(asset);
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/rmassetData', [asset, mid]);

        },

        chkAsset: function(asset, mid) {
            // return $http({
            //     method: "POST",
            //     url: "/checkAssetData"
            // }).then(function(response) {
            //     console.log(response.data);
            // }, function(response) {
            //     console.log(response.statusText);
            // });
            return $http.post('http://digital-coe-api.azurewebsites.net/vroom/checkAssetData', [asset, mid]);
        }


    };

});