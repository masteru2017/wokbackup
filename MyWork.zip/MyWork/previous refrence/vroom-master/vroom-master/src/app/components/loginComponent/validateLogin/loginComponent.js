var loginCmp = angular.module('loginCmp', []);

loginCmp.component('loginComponent', {
    require: {
        parent: '^parentComponent'
    },
    bindings: {
        user: '=',
        image: '='
    },
    templateUrl: 'app/components/loginComponent/validateLogin/login.html',
    controller: function() {
        var sef = this;

    }
});


loginCmp.controller("loginController", ['$scope', '$location', 'adalAuthenticationService', function($scope, $location, adalAuthenticationService) {
    var self = this;
    self.userName = '';
    self.urlImg = '';

    if (adalAuthenticationService.userInfo && adalAuthenticationService.userInfo.isAuthenticated) {
        console.log("Authenticated");
        $location.path('/home');
    } else {
        console.log("not authenticated");
    }

    $scope.login = function() {
        adalAuthenticationService.login();

    };


}]);

// loginCmp.controller("loginController", ['$location', 'adalAuthenticationService', function($scope, $location, adalAuthenticationService) {

//     var self = this;
//     self.userName = '';
//     self.urlImg = '';


//     console.log(adalAuthenticationService);
//     $scope.login = function() {
//         console.log("login");
//         adalAuthenticationService.login();
//         console.log(adalAuthenticationService);
//         console.log(adalAuthenticationService.userInfo.isAuthenticated);


//         if (adalAuthenticationService.userInfo && adalAuthenticationService.userInfo.isAuthenticated) {
//             console.log("Authenticated");
//             console.log("in if");
//             // var getPhoto = function(adalAuthenticationService) {
//             //     var adal = new AuthenticationContext(adalAuthenticationService.config);
//             //     adal.acquireToken("https://graph.microsoft.com", function(error, token) {
//             //         var request = new XMLHttpRequest();
//             //         request.open("GET", "https://graph.microsoft.com/beta/me/Photo/$value");
//             //         request.setRequestHeader("Authorization", "Bearer " + token);
//             //         request.responseType = "blob";
//             //         request.onload = function() {
//             //             if (request.readyState === 4 && request.status === 200) {
//             //                 var reader = new FileReader();
//             //                 reader.onload = function() {
//             //                     console.log("sending url");
//             //                     console.log(reader.result);
//             //                     self.fetch(reader.result);
//             //                 };
//             //                 reader.readAsDataURL(request.response);
//             //             }
//             //         };
//             //         request.send(null);
//             //     });
//             // };
//             // console.log(getPhoto(adalAuthenticationService));
//             // self.userName = adalAuthenticationService.userInfo.profile.name;

//             // self.fetch = function(url) {
//             //     console.log("fetching url");

//             //     self.urlImg = url;
//             // };



//             $location.path('/home');
//         } else {
//             console.log("not authenticated");
//         }

//     };
// }]);