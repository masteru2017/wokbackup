var app = angular.module("userApp");

app.component('editModalComponent', {
    require: {
        parent: '^editDesign'
    },
    templateUrl: 'app/components/editSavedDesignComponent/saveDesignModal/modalWindow.html',
    controller: function($cookies) {
        var self = this;
        // self.$onInit = function() {
        //     self.parent.designName = this.designName;
        //     self.parent.designAccess = this.designAccess;
        // };
        console.log($cookies.getObject("savedRoom").designName);
        self.name = $cookies.getObject("savedRoom").designName;
        console.log(self.name);

        self.Save = function() {
            console.log("this design name ", self.designName);
            console.log("this design access ", self.designAccess);
            // this.parent.getData(this.designName, this.designAccess);
            this.parent.getData(self.name, this.designAccess);
            // console.log(this.designName);
            this.parent.download();
        };
    }
});