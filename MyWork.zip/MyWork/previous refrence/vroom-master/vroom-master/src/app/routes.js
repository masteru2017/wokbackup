app.config(['$stateProvider', '$urlRouterProvider', '$httpProvider', 'adalAuthenticationServiceProvider',
    function($stateProvider, $urlRouterProvider, $httpProvider, adalProvider) {
        $urlRouterProvider.otherwise("/login");
        $stateProvider
            .state('login', {
                url: "/login",
                templateUrl: "app/components/loginComponent/validateLogin/login.html"
            })
            .state('home', {
                url: "/home",
                templateUrl: "app/components/userHomeComponent/userHomeComponent/userHomeTemplate.html",
                requireADLogin: true
            })
            .state('userCategory', {
                url: "/userCategory",
                templateUrl: "app/components/userNewCategoryComponent/userNewCategory/userNewCategoryTemplate.html"
            })
            .state('userThemes', {
                url: "/userThemes",
                templateUrl: "app/components/userNewThemeComponent/userNewTheme/userNewThemeTemplate.html"
            })
            .state('userRooms', {
                url: "/userRooms",
                templateUrl: "app/components/userNewRoomComponent/userNewRoom/userNewRoomTemplate.html"
            })
            .state('userSavedDesign', {
                url: "/userSavedDesign",
                // templateUrl: "app/components/common/userNavbar/userNavbarTemplate.html"
                templateUrl: "app/components/userSavedDesignComponent/userSavedDesign/userSavedDesignGalleryTemplate.html"
            })
            .state('userAssets', {
                url: "/userAssets",
                templateUrl: "app/components/userAssetCollectionComponent/userAssetCollection/userAssetCollectionTemplate.html"
            })
            .state('userAsset', {
                url: "/userAsset",
                templateUrl: "app/components/userAssetPageComponent/userAssetTemplate.html"
            })
            .state('userDesign', {
                url: "/userDesign",
                templateUrl: "app/components/userDesignPageComponent/userDesignPage/userDesignPageTemplate.html"
            })
            .state('editDesign', {
                url: "/editDesign",
                templateUrl: "app/components/editSavedDesignComponent/editSavedDesign/editSavedDesignTemplate.html"
            })
            .state('help', {
                url: "/help",
                templateUrl: "app/components/helpComponent/helpTemplate.html"
            });

        adalProvider.init({
                instance: 'https://login.microsoftonline.com/',
                tenant: '85c997b9-f494-46b3-a11d-772983cf6f11',
                //clientId: '21e994ca-6f16-4a38-9647-e2dd3db5908c',
                clientId: '980935df-05b5-47d1-a825-5ea1e20913b7',
                extraQueryParameter: 'nux=1',
                // redirectUri: 'http://localhost:9890/home'
                //cacheLocation: 'localStorage', // enable this for IE, as sessionStorage does not work for localhost.
            },
            $httpProvider
        );
    }
]);