var app = angular.module('vrApp', ['ui.router', 'AdalAngular', 'userApp', 'loginCmp', 'mgcrea.bootstrap.affix', 'ngCookies']);


app.component('parentComponent', {
    transclude: true,
    template: '<div ui-view></div>',
    // <div id="loader">LOADING</div>


    bindings: {
        user: '=',
        image: '='
    },

});

app.directive('resolveLoader', ['$http', '$rootScope', '$timeout', function($http, $rootScope, $timeout) {
    return {
        restrict: 'E',
        replace: true,
        templateUrl: 'app/components/common/loader/loader.html',
        link: function(scope, element, attrs) {
            scope.isLoading = function() {
                return $http.pendingRequests.length > 0;
            };
            scope.$watch(scope.isLoading, function(value) {
                if (value) {
                    element.removeClass('ng-hide');
                } else {
                    element.addClass('ng-hide');
                }
            });
            $rootScope.$on('$stateChangeStart', function(event, currentRoute, previousRoute) {
                console.log("route change started");
                element.removeClass('ng-hide');

            });
            $rootScope.$on('$stateChangeSuccess', function() {
                console.log("Sucess changing");
                element.removeClass('ng-hide');
            });
        }
    };
}]);